from django.contrib import admin
from about.models import About
# Register your models here.

admin.site.register((About))